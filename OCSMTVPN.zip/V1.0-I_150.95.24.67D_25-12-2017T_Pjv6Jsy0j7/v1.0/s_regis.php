<?
include "include/db.config.inc.php";
	
	    if($_POST["2dthUser"] == "")
	{
		header('Location: register.php?user=error');
		exit();
	}
		if($_POST["2dthPass"] == "")
	{
		header('Location: register.php?pass=error');
		exit();
	}
		if($_POST["2dthCpass"] == "")
	{
		header('Location: register.php?cpass=error');
		exit();
	}
		if($_POST["2dthName"] == "")
	{
		header('Location: register.php?name=error');
		exit();
	}
		if($_POST["2dthEmail"] == "")
	{
		header('Location: register.php?email=error');
		exit();
	}
		if($_POST["2dthPhone"] == "")
	{
		header('Location: register.php?phone=error');
		exit();
	}
		if($_POST["2dthCheck"] == "")
	{
		header('Location: register.php?check=error');
		exit();
	}
	$strSQL = "SELECT * FROM member WHERE Username = '".trim($_POST['2dthUser'])."' ";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
	if($objResult)
	{
			header('Location: register.php?usera=error');
	}
	 else
	{	
	 $strSQL = "SELECT * FROM member WHERE Email = '".trim($_POST['2dthEmail'])."' ";
	 $objQuery = mysql_query($strSQL);
	 $objResult = mysql_fetch_array($objQuery);
	 if($objResult)
	  {
			header('Location: register.php?emaila=error');
	  }
	  else
	  {	
		$strSQL = "INSERT INTO member (Username,Password,Name,Email,Phone) VALUES ('".$_POST["2dthUser"]."', 
		'".$_POST["2dthPass"]."','".$_POST["2dthName"]."','".$_POST["2dthEmail"]."','".$_POST["2dthPhone"]."')";
		$objQuery = mysql_query($strSQL);
		
		header('Location: login.php?reg=com');
		
   	  }
     }
	mysql_close();
?> 
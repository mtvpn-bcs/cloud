<?
	header("location: installer/install.php");
?>
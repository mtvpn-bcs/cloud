<?
include("header.php");
?>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
include("nav.php");
?>
<html>
<head>
<title><?php require('setting.php'); echo $CS_2DTHCip;
?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<form name="form1" method="post" action="host.php?set=suc&host=">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require('setting.php'); echo $CS_2DTHChip;
?>
	<?
	if($_GET['set'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-success'>";
echo $CS_2DTHSuc;
echo "</span>";
	}
	?>
	<?
	if($_GET['get'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $CS_2DTHErr;
echo "</span>";
	}
	?></h3>
  </div>
  <div class="panel-body">
<div class="row">

  <div class="col-lg-6">
 <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require('setting.php'); echo $CS_2DTHHos;
?>    <?
	if($_GET['ip'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $CS_2DTHRhos;
echo "</span>";
	}
	?>
</button>
      </span>
      <input value="<?$hosts = $_GET["host"]; echo $hosts;?>" type="text" class="form-control" name="2dthHost" placeholder="<?php require('setting.php'); echo $CS_2DTHHost;
?>">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

   <div class="col-lg-6">
   <div class="input-group">
      <span class="input-group-btn">
       <button class="btn btn-default" type="button"><?php function rand_code($len)
{
 $min_lenght= 0;
 $max_lenght = 100;
 $bigL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
 $smallL = 'abcdefghijklmnopqrstuvwxyz';
 $number = '0123456789';
 $bigB = str_shuffle($bigL);
 $smallS = str_shuffle($smallL);
 $numberS = str_shuffle($number);
 $subA = substr($bigB,0,5);
 $subB = substr($bigB,6,5);
 $subC = substr($bigB,10,5);
 $subD = substr($smallS,0,5);
 $subE = substr($smallS,6,5);
 $subF = substr($smallS,10,5);
 $subG = substr($numberS,0,5);
 $subH = substr($numberS,6,5);
 $subI = substr($numberS,10,5);
 $RandCode1 = str_shuffle($subA.$subD.$subB.$subF.$subC.$subE);
 $RandCode2 = str_shuffle($RandCode1);
 $RandCode = $RandCode1.$RandCode2;
 if ($len>$min_lenght && $len<$max_lenght)
 {
 $CodeEX = substr($RandCode,0,$len);
 }
 else
 {
 $CodeEX = $RandCode;
 }
 return $CodeEX;
}
echo rand_code(5);
?>  <?
	if($_GET['cap'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $CS_2DTHRcap;
echo "</span>";
	}
	?></button>
      </span>
      <input type="text" class="form-control" name="2dthCap" placeholder="<?php require('setting.php'); echo $CS_2DTHCap;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

<br><br>

<?php
if($_POST['2dthHost'] == '')
{
echo "
<div class='col-lg-6'>
     <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $CS_2DTHIps;
echo " <span class='badge'>";
echo $CS_2DTHUnk;
echo "</span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

    <div class='col-lg-6'>
     <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $CS_2DTHStas;
echo "<span class='badge'>";
echo $CS_2DTHUnkn;
echo "</span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
";
}
else
{
	$ho = $_POST['2dthHost'];
	$ip = gethostbyname($_POST['2dthHost']);
echo "<div class='col-lg-6'>
     <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $CS_2DTHIp;
echo " <a target='_blank' href='http://$ho/'>$ho</a><span class='badge'>$ip</span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

    <div class='col-lg-6'>
     <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $CS_2DTHSta;
echo "<span class='badge'>";
echo $CS_2DTHSucc;
echo "</span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->";
}
?>
<div align="center">
      <input type="submit" name="Submit" value="<?php require('setting.php'); echo $CS_2DTHChiph;
?>" class="btn btn-default">
      <a onclick="goBack()" value="<?php require('setting.php'); echo $CS_2DTHCance;
?>" class="btn btn-default"><?php require('setting.php'); echo $CS_2DTHCance;
?></a>
</form>

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="<?php require('setting.php'); echo $S_2DTHUrl;
?>";
}
</script>
</body>
</html>
<?
include("header.php");
?>
<title><?php require("setting.php"); echo $OS_2DTHEserv; echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRadmin;
		echo $S_2DTHUser;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	
		if($_POST["2dthName"] == "")
	{
		header("Location: e-server.php?name=error&serverid=".$_GET["serverid"]);
		exit();
	}
		if($_POST["2dthIP"] == "")
	{
		header("Location: e-server.php?ip=error&serverid=".$_GET["serverid"]);
		exit();
	}
		if($_POST["2dthPoint"] == "")
	{
		header("Location: e-server.php?point=error&serverid=".$_GET["serverid"]);
		exit();
	}
		if($_POST["2dthRegion"] == "")
	{
		header("Location: e-server.php?region=error&serverid=".$_GET["serverid"]);
		exit();
	}
		if($_POST["2dthUSER"] == "")
	{
		header("Location: e-server.php?user=error&serverid=".$_GET["serverid"]);
		exit();
	}
		if($_POST["2dthPASS"] == "")
	{
		header("Location: e-server.php?pass=error&serverid=".$_GET["serverid"]);
		exit();
	}
?>
<html>
<head>
<title><?php require("setting.php"); echo $OS_2DTHEserv;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<?
include "include/db.config.inc.php";
$TdthID = $_GET["serverid"];
$TdthIP = $_POST["2dthIP"];
$TdthPoint = $_POST["2dthPoint"];
$TdthName = $_POST["2dthName"];
$TdthRegion = $_POST["2dthRegion"];
$strSQL = "UPDATE SIB SET SIA = '".$_POST['2dthIP']."' 
,SIU = '".$_POST['2dthUSER']."'
,SIP = '".$_POST['2dthPASS']."'
,SIB = '".$_POST['2dthPoint']."'
,SIN = '".$_POST['2dthName']."'
,SIT = '".$_POST['2dthRegion']."'
WHERE SID = '".$_GET["serverid"]."' ";
$objQuery = mysql_query($strSQL);
include "nav.php";
require "setting.php";
echo "<div class='panel panel-default'>
  <div class='panel-heading'>
    <h3 class='panel-title'>";
echo $OS_2DTHDet;
echo " <span class='label label-success'>";
echo $OS_2DTHSuc;
echo "</span>
	</h3>
  </div>
  <div class='panel-body'>
<div class='row'>

    <div class='col-lg-6'>
   <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $OS_2DTHNam;
echo "<span class='badge'> $TdthName </span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class='col-lg-6'>
     <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $OS_2DTHIp;
echo "<span class='badge'> $TdthIP </span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

<div class='col-lg-6'>
   <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $OS_2DTHPri;
echo "<span class='badge'> $TdthPoint </span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

  <div class='col-lg-6'>
     <ul class='list-group'>
  <li class='list-group-item'>
        ";
echo $OS_2DTHReg;
echo "<span class='badge'> $TdthRegion </span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->
<br><br>

</div><!-- /.row -->
 </div>
</div>
<br><br>

<div align='center'>
     <a href='relog.php' onclick='goBack()' type='button' name='Submit' class='btn btn-default'>";
echo $OS_2DTHHom;
echo "</a>
      <a href='profile.php' onclick='goHome()' name='Cancel' class='btn btn-default'>";
echo $OS_2DTHPro;
echo "</a>";		

mysql_close();
?>

<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="relog.php";
}
function goHome() {
    window.location="profile.php";
}
</script>
</body>
</html>
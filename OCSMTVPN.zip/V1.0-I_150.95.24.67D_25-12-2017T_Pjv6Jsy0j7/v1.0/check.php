<?
   session_start();
   if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
    else
    {
		if($_GET["servers"] == "check")
	  {
	  include "include/db.config.inc.php";
      $strSQL = "SELECT * FROM SIB  WHERE SID = '".$_GET["server"]."' ";
      $objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
      $objResult = mysql_fetch_array($objQuery);
	  $AIP = $objResult['SIA'];
      $NIP = $objResult['SIN'];
      echo "<html>
	  <head>
	  <meta charset='UTF-8'>
	  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
	  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
	  <link href='css/bootstrap.min.css' rel='stylesheet'>
	  <!--[if lt IE 9]>
      <script src='https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js'></script>
      <script src='https://oss.maxcdn.com/respond/1.4.2/respond.min.js'></script>
	  <![endif]-->
	  <script src='js/bootstrap.js'></script>
	  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js'></script>
	  <title>";
echo $SE_2DTHCho;
echo "
  $NIP </title>
	  </head>
	  <div class='list-group'>
	  <a href='relog.php' class='list-group-item active'>
	  <h4 class='list-group-item-heading'> $NIP </h4>
	  <p class='list-group-item-text'>";
echo $SE_2DTHSuc;
echo "
</p>
	  </a>
	  <div align='right' class='list-group-item'>
	  <h4 class='list-group-item-heading'>
	  ";
echo $SE_2DTHRed;
echo "
 ";
echo $SE_2DTHSym;
echo "
 ";
echo $SE_2DTHOf;
echo "

	  ";
echo $SE_2DTHGreen;
echo "
 ";
echo $SE_2DTHSym;
echo "
 ";
echo $SE_2DTHOn;
echo "

	  </h4>
	  <p class='list-group-item-text'>
	  <a href='relog.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
	  ";
echo $SE_2DTHBuy;
echo "
</a>
	  <a href='profile.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
	  ";
echo $SE_2DTHPro;
echo "
</a>
	  </p>
	  </div>
	  </div>
	  <iframe src='https://check.2dth.club/ip.php?check=$AIP' width='100%' height='100%' frameBorder='0'>Browser not compatible.</iframe>
	  <script src='js/bootstrap.js'></script>
	  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js'></script>
	  </body>
	  </html>
	  ";
	  exit();
	  }
     
	 else
		{
	 header('Location: check.2dth.club/ip.php?check=127.0.0.1');
     exit();
	 }
    }


<?
   session_start();
   $dlid = $_GET["serverdl"];
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRadmin;
		echo $S_2DTHUser;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}	
    else
    {
		if($_GET["confirm"] == "ok")
	  {
			require("setting.php");
	  include "include/db.config.inc.php";
	  $strSQL = "DELETE FROM SIB WHERE SID = '".$_GET["serverdl"]."' ";
	  $objQuery = mysql_query($strSQL);
      echo "<html>
	  <head>
	  <meta charset='UTF-8'>
	  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
	  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
	  <link href='css/bootstrap.min.css' rel='stylesheet'>
	  <!--[if lt IE 9]>
      <script src='https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js'></script>
      <script src='https://oss.maxcdn.com/respond/1.4.2/respond.min.js'></script>
	  <![endif]-->
	  <script src='js/bootstrap.js'></script>
	  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js'></script>
	  <title>";
echo $DL_2DTHDlsuc;
echo "
</title>
	  </head>
	  <div class='list-group'>
	  <a href='#' class='list-group-item active'>
	  <h4 class='list-group-item-heading'>";
echo $DL_2DTHConf;
echo "
</h4>
	  <p class='list-group-item-text'>";
echo $DL_2DTHSuc;
echo "
</p>
	  </a>
	  <div align='right' class='list-group-item'>
	  <h4 class='list-group-item-heading'>
	  ";
echo $DL_2DTHCh;
echo "

	  </h4>
	  <p class='list-group-item-text'>
	  <a href='relog.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
	  ";
echo $DL_2DTHBuy;
echo "
</a>
	  <a href='list-server.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
	  ";
echo $DL_2DTHList;
echo "
</a>
	  </p>
	  </div>
	  </div>
	  <iframe src='https://ads.2dth.club/' width='100%' height='100%' frameBorder='0'>Browser not compatible.</iframe>
	  <script src='js/bootstrap.js'></script>
	  <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js'></script>
	  </body>
	  </html>
	  ";
	  exit();
	  }
     
	 else
		{
		 require("setting.php");
	 echo "<html>
     <head>
     <meta charset='UTF-8'>
     <meta name='viewport' content='width=device-width, initial-scale=1.0'>
     <meta http-equiv='X-UA-Compatible' content='IE=edge'>
     <link href='css/bootstrap.min.css' rel='stylesheet'>
     <!--[if lt IE 9]>
     <script src='https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js'></script>
     <script src='https://oss.maxcdn.com/respond/1.4.2/respond.min.js'></script>
     <![endif]-->
     <script src='js/bootstrap.js'></script>
     <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js'></script>
     <title>";
echo $DL_2DTHDl;
echo "
</title>
     </head>
     <div class='list-group'>
     <a href='#' class='list-group-item active'>
     <h4 class='list-group-item-heading'>";
echo $DL_2DTHDlc;
echo "
</h4>
     <p class='list-group-item-text'>";
echo $DL_2DTHTx;
echo "
</p>
     </a>
     <div align='right' class='list-group-item'>
     <h4 class='list-group-item-heading'>
     ";
echo $DL_2DTHCan;
echo "

     </h4>
     <p class='list-group-item-text'>
     <a href='dl.php?serverdl=$dlid&dl=yes&confirm=ok' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
     ";
echo $DL_2DTHYes;
echo "
</a>
     <a href='list-server.php' type='button' class='btn btn-primary'      aria-haspopup='true' aria-expanded='false'>
     ";
echo $DL_2DTHNo;
echo "
</a>
     </p>
     </div>
     </div>
     <iframe src='https://ads.2dth.club/' width='100%' height='100%' frameBorder='0'>Browser not compatible.</iframe>
     <script src='js/bootstrap.js'></script>
     <script                src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js'></script>
     </body>
     </html>
     ";
     exit();
	 }
    }


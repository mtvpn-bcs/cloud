<?
include("header.php");
?>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}
	
include "include/db.config.inc.php";
include("nav.php");
	$strSQL = "SELECT * FROM user WHERE US = '".$_SESSION["Usernames"]."' ";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$strSQL .=" order by UID DESC";
$objQuery  = mysql_query($strSQL);
?>
<html>
<head>
<title><?php require("setting.php"); echo $SV_2DTHSer;
echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>

<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $SV_2DTHServi;?></h3>
  </div>
  <div class="panel-body">
<div class="row">

<?
while($objResult = mysql_fetch_array($objQuery))
{
?>

    <div class="col-lg-6">
   <ul class="list-group">
  <li class="list-group-item">
         <?php require("setting.php"); echo $SV_2DTHUs;?>&nbsp;<?=$objResult['UU'];?><span class="badge"><?php require("setting.php"); echo $SV_2DTHPs;?>&nbsp;<?=$objResult['UP'];?></span>
    </li>
</ul>
  </div><!-- /.col-lg-6 -->

    <?
}
?>
</div><!-- /.row -->
 </div>
</div>
<br><br>

<?
include("footer.php");
?>
</body>
</html>
	</div>
</div>
<iframe src="https://ads.2dth.club/" width="100%" height="100%" frameBorder="0"><?php require("setting.php"); echo $WS_2DTHNot;?>.</iframe>
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</body>
</html>

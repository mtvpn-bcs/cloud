<?php
@session_start();
header("Content-type: text/html; charset=utf-8");
set_time_limit(0);
$datenow=date("Y-m-d");
$transaction_leng=14;
include 'common.php';
include 'config.php';
if(!isset($_SESSION['UIDS']))
	$_SESSION['UIDS'] = '';
		
?>
<?
if($_GET["Action"] == "Save")
{
	session_start();
include "config.php";
	$strSQL = "SELECT * FROM member WHERE Username = '".trim($_POST['2dthUser'])."' OR Email = '".trim($_POST['2dthUser'])."' 
	and Password = '".trim($_POST['2dthPass'])."'";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
	if(!$objResult)
	{
			header('Location: tmwpay.php?error=pass');
	}
	else
	{
			$_SESSION["UIDS"] = $objResult["UserID"];
			$_SESSION["Usernames"] = $objResult["Username"];
			$_SESSION["Status"] = $objResult["Status"];
			session_write_close();
			header('Location: tmwpay.php');
	}
	mysql_close(); 
	}
?>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> 
</head> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php
if($_SESSION['UIDS'] == '')
{
	echo "";
echo $TW_2DTHLog;
echo "
";
}
else
{
echo "";
echo $TW_2DTHPay;
echo "
";
}
?></title>
  </head>
  <body>
<?php
if($_SESSION['UIDS'] == '')
{
?>
<html>
<head>
<meta charset='UTF-8'>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<title><?php require("../setting.php"); echo $TW_2DTHLog;
?> </title>
</head>
<div class="list-group">
  <a href="#" class="list-group-item active">
    <h4 class="list-group-item-heading"><?php require("../setting.php"); echo $TW_2DTHTm;
?> </h4>
    <p class="list-group-item-text"><?php require("../setting.php"); echo $TW_2DTHRlog;
?> </p>

  </a>
    <div align="right" class="list-group-item">
<marquee><?php require("../setting.php"); echo $TW_2DTHPos;
?> </marquee>

	</div>
</div>
<div align="center">
 <?
	if($_GET['reg'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-success'>";
echo $TW_2DTHRegs;
echo "
</span>";
	}
	?>
	</div>
<div class="row">
    <div class="Absolute-Center is-Responsive">
      <div id="logo-container"></div>
      <div class="col-sm-12 col-md-10 col-md-offset-1">
<form name="form1" method="post" action="?Action=Save">
	  <?
	if($_GET['error'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $TW_2DTHErr;
echo "
</span>";
	}
	?><br>
 <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input class="form-control" type="text" name='2dthUser' placeholder="<?php require("../setting.php"); echo $TW_2DTHUs;
?> "/>          
          </div>
	
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
            <input class="form-control" type="password" name='2dthPass' placeholder="<?php require("../setting.php"); echo $TW_2DTHPs;
?> "/>     
          </div>
          <div class="checkbox">
            <label>
              <input type="checkbox"> <?php require("../setting.php"); echo $TW_2DTHCh;
?>  
            </label>
          </div>
          <div class="form-group">
            <input name="login" class="btn btn-def btn-block" type="submit" name="Submit" value="<?php require("../setting.php"); echo $TW_2DTHLogi;
?> ">
          </div>

          <div class="form-group text-center">
            <a href="../register.php"><?php require("../setting.php"); echo $TW_2DTHRegi;
?> </a>&nbsp;|&nbsp;<a href="../about.php"><?php require("../setting.php"); echo $TW_2DTHTerm;
?> </a>
          </div>

</form>
</div>
</div>
</div>


<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</body>
</html>

<?
}
else 
	{
	?>
<html>
<head>
<meta charset='UTF-8'>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<title><?php require("../setting.php"); echo $TW_2DTHTmp;
?></title>
</head>
							<form action="?topup=yes" name="form1" method="post">
							<INPUT TYPE="hidden" NAME="send" value="ok">
		<INPUT TYPE="hidden" NAME="session" value="<?=$capchar_session?>">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("../setting.php"); echo $TW_2DTHPoius;
?>  <?echo $_SESSION['Usernames'];  ?>
	<?
	if($_GET['set'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-success'>";
echo $TW_2DTHSuc;
echo "
</span>";
	}
	?></h3>
  </div>
  <div class="panel-body"><div class="alert alert-info" role="alert">
			<?php require("../setting.php"); echo $TW_2DTHI1;
?> กรุณาโอนมาที่ <?php require("config.php"); echo $truewall_phone;
?>
			</div>
<div class="row">
<div class="col-lg-6">

    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("../setting.php"); echo $TW_2DTHNum;
?></button>
      </span>
      <input type="text" id="transactionid" name="transactionid" class="form-control" placeholder="<?php require("../setting.php"); echo $TW_2DTHNumb;
?>" onkeypress="return isNumberKey(event)" maxlength=14 required autocomplete="off">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
  <?
	if($_GET['cap'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $TW_2DTHRcap;
echo "
</span>";
	}
	?>
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?
function generateRandomString($length = 5) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
echo generateRandomString();
?></button>
      </span>
      <input name="2dthCap" type="text" maxlength=5 required autocomplete="off" class="form-control" placeholder="<?php require("../setting.php"); echo $TW_2DTHCap;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->


</div><!-- /.row --><br><br>
 </div>
<?php
if($_GET["topup"] == "yes"){
	require "../setting.php";
	if(strlen($_POST[transactionid])<10){?>
		  	<div class="alert alert-danger" role="alert">
			<?php require("../setting.php"); echo $TW_2DTHI2;
?>
			</div>
				<?
				}else{
	$returnserver=tmtopupconnect($tmapi_user,$tmpapi_assword,$truewall_email,$truepassword,my_ip(),$_POST[session],$_POST[transactionid],"yes",$_SESSION['UIDS']);
	}
	if(substr($returnserver,0,2)=="ok"){
		$money_total=substr($returnserver,2);

		$strSQL="update member set Point=Point+'$money_total' WHERE UserID = '".$_SESSION["UIDS"]."' ";
$objQuery = mysql_query($strSQL);?>
	<div class="alert alert-success" role="alert">
			<?php require("../setting.php"); echo $TW_2DTHI3;
?> <?echo $money_total; ?><?php require("../setting.php"); echo $TW_2DTHI4;
?>
			</div>
	<?}else{
		$error=$returnserver;?>
		  	<div class="alert alert-danger" role="alert">
			<?php require("../setting.php"); echo $TW_2DTHI5;
?> <?echo $error; ?>
			</div>
				<?}
} else{
	$capchar_session=capchar(my_ip(),$tmapi_user);
	$returnserver=tmtopupconnect($tmapi_user,$tmpapi_assword,"","","","","","","");
	if($returnserver=="ready"){
?>
<script>
co=0;
function loading(){
	co=co+1;
	switch(co)
	{
		case 1:
		char_load="โปรดรอสักครู่ ครับ |";
		break;
		case 2:
		char_load="โปรดรอสักครู่ ครับ /";
		break;
		case 3:
		char_load="โปรดรอสักครู่ ครับ -";
		break;
		case 4:
		char_load="โปรดรอสักครู่ ครับ \\";
		co=0;
		break;
	}
	document.getElementById("loadvip").innerHTML=char_load;
	setTimeout("loading()", 100);
}	

</script>
<?php 
	} 
     else if($returnserver=="noready"){
		echo $TW_2DTHI6;
	}else if($returnserver=="not_connect"){
		echo $TW_2DTHI7;
	}else if($returnserver=="block_ip"){
		echo $TW_2DTHI8;
	}else{
		echo $TW_2DTHI9;
	}
}
?><p align="center">
<img width="80%" height="40%" src="../img/data/transactionid.jpg">
</p>
</div>
<br><br>

<div align="center">
      <input type="submit" name="send" value="<?php require("../setting.php"); echo $TW_2DTHConf;
?>" class="btn btn-default">
      <a onclick="goBack()" value="<?php require("../setting.php"); echo $TW_2DTHCance;
?>" class="btn btn-default"><?php require("../setting.php"); echo $TW_2DTHCance;
?></a>
</form>
							
						<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script>
function goBack() {
    window.location="cache.php?url=../";
}
function goHome() {
    window.location="../";
}
</script>
</body>
</html>

<?
}
?>
<?php
class TrueWallet{
    //Mysql
	private $DbUser = 'root'; //ชื่อผู้ใช้ฐานข้อมูล mysql
	private $DbPass = '1234'; //รหัสผ่านฐานข้อมูล mysql
	private $DbName = '2DTHSSHVPN'; //ชื่อฐานข้อมูล
	//<--ข้อมูลด้านล่างหากไม่ได้เปลี่ยนเเปลงกรุณาอย่าเปลี่ยน-->//
	private $DbHost = 'localhost'; //ที่อยู่ฐานข้อมูล mysql
	private $DbPort = '3306'; //พอร์ตฐานข้อมูล mysql
	private $tbName = 'member'; //ชื่อตารางที่เก็บข้อมูลยูเซอร์
	private $fdID = 'Username'; //ฟิลด์ไอดี
	private $fdPS = 'Password'; //ฟิลด์พาสเวิร์ด
	private $fdCS = 'Point'; //ฟิลด์พ้อย	
	private $DbQuery;
	//<--ข้อมูลด้านบนหากไม่ได้เปลี่ยนเเปลงกรุณาอย่าเปลี่ยน-->//
	//End-Mysql

	//True Money
	private $trueID = '2dth@gmail.com'; //อีเมลสำหรับล็อคอินทรูวอเล็ต
	private $truePS = '1234'; //รหัสผ่านสำหรับล็อคอินทรูวอเล็ต
	private $passhash;
	//End-True Money
	
	//Config TrueWallet ห้ามแก้ไขหากไม่รู้ค่าที่แท้จริง
	private $login_type = "email"; 
	private $api_signin = "https://api-ewm.truemoney.com/api/v1/signin?&"; 
	private $api_profile = "https://api-ewm.truemoney.com/api/v1/profile/"; 
	private $api_topup = "https://api-ewm.truemoney.com/api/api/v1/topup/mobile/"; 
	private $device_os = "android"; 
	private $device_id = "d520d0d12d0d48cb89394905168c6ed5"; 
	private $device_type = "CPH1611"; 
	private $device_version = "6.0.1"; 
	private $app_name = "wallet"; 
	private $app_version = "2.9.14"; 
	private $deviceToken = "fUUbZJ9nwBk:APA91bHHgBBHhP9rqBEon_BtUNz3rLHQ-sYXnezA10PRSWQTwFpMvC9QiFzh-CqPsbWEd6x409ATC5RVsHAfk_-14cSqVdGzhn8iX2K_DiNHvpYfMMIzvFx_YWpYj5OaEzMyIPh3mgtx"; 
	private $mobileTracking = "dJyFzn/GIq7lrjv2RCsZbphpp0L/W2 PsOTtOpg352mgWrt4XAEAAA=="; 
	private $walletToken = '';
	//End Config
	
	//Point-พ้อยที่จะได้รับ ตามราคาบัตร
	private $point1 	= 50; //50 บาท
	private $point2 	= 90; //90 บาท
	private $point3 	= 150; //150 บาท
	private $point4 	= 300; //300 บาท
	private $point5 	= 500; //500 บาท
	private $point6 	= 1000; //100 บาท
	//End-Point
		
	public function __construct() {
		$this->passhash = sha1($this->trueID.$this->truePS);
	}
	
	private function GetToken(){
		$url = $this->api_signin.'device_os='.$this->device_os.'&device_id='.$this->device_id.'&device_type='.$this->device_type.'&device_version='.$this->device_version.'&app_name='.$this->app_name.'&app_version='.$this->app_version;
		$header = array(
			"Host: api-ewm.truemoney.com",
			"Content-Type: application/json"
		);
		$postfield = array(
			"username"=>$this->trueID,
			"password"=>$this->passhash,
			"type"=>$this->login_type,
			"deviceToken"=>$this->deviceToken,
			"mobileTracking"=>$this->mobileTracking,
		);	
		return $this->wallet_curl($url,json_encode($postfield),$header);
	}

	public function Profile(){
		$url = $this->api_profile.$this->walletToken.'?&device_os=android&device_id='.$this->device_id.'&device_type='.$this->device_type.'&device_version='.$this->device_version.'&app_name='.$this->app_name.'&app_version='.$this->app_version;
		$header = array("Host: api-ewm.truemoney.com");
		return $this->wallet_curl($url,false,$header);	
	}
	
	/*
	*/
	private function wallet_curl($url,$data,$header){	
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);  
		if($data){
			curl_setopt($ch,CURLOPT_CUSTOMREQUEST, "POST");                                                                     
			curl_setopt($ch,CURLOPT_POSTFIELDS, $data);         
		}                                  
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);   
		curl_setopt($ch,CURLOPT_USERAGENT,'');
		$result = curl_exec($ch);
		return json_decode($result,true);
	}
	
	/*
	@param1 $user = ไอดีที่จะเติม
	@param2 $card = เลขบัตรทรูมันนี่
	
	return code -9999 = ยูเซอร์ที่จะเติมว่างเปล่า หรือ เลขบัตรว่างเปล่า หรือ เลขบัตรไม่ใช่ตัวเลข หรือ เลขบัตรน้อยกว่า 14 หลัก
	return code -1001 = บัตรใช้ไปแล้ว หรือ มีในฐานข้อมูลแล้ว
	return code -1002 = เติมผิด หรือ บัตรมั่ว
	return code 20000 = เติมสำเร็จ
	*/	
	public function Topup($user,$card){	
		//เช็คไอดีและบัตร
		if($user == '' || $card == '' || !is_numeric($card) || strlen($card) < 14)
		{
			echo "<div class='alert alert-danger' role='alert'>";
			echo "ไม่สามารถเติมเงินได้ ไม่พบชื่อผู้ใช้งานนี้หรือเลขบัตรนี้";
			echo "สถานะ : ";
			return -9999;
			echo "</div>";
		}
		//จบการเช็คไอดีและบัตร

		//เช็คเลขบัตรซ้ำ
		if(!$this->CheckCard($card))
		{
			echo "<div class='alert alert-info' role='alert'>";
			echo "หมายเลขบัตรนี้ถูกใช้งานไปเเล้ว ";
			echo "สถานะ : ";
			return -1001;
			echo "</div>";
		}
		//จบการเช็คเลขบัตรซ้ำ

		$token = $this->GetToken();
		$url = $this->api_topup.time()."/".$token['data']['accessToken']."/cashcard/".$card;
		$header = array("Host: api-ewm.truemoney.com");
		$topup = $this->wallet_curl($url,true,$header);

		if($topup['code'] < 0){ //-1001 = บัตรใช้ไปแล้ว  // -1002 = บัตรผิด หรือ บัตรมั่ว
			$amount = 0;
			$status = $topup['code'];
			echo "<div class='alert alert-warning' role='alert'>";
            echo "หมายเลขบัตรไม่ถูกต้อง ";
			echo "สถานะ : ";
		}else if($topup['transactionId'] <> ''){ //เติมเงินสำเร็จ
			$amount = $topup['amount'];
			$status = 20000;
			echo "<div class='alert alert-success' role='alert'>";
			echo "ทำการเติมเงินได้เสร้จสิ้น ";
			echo "จำนวน : $this->GetPoint($amount บาท) ถ้วน ";
		    echo "สถานะ : ";

		}
		if(!$this->InsertCard($user, $card, $amount, $status)){
			//หาก insert ไม่ได้ให้สร้าง error log
			$update = "INSERT INTO truemoney (card, uid, uip, amount, status, time) VALUES ('$card', '$user', '".$this->GetUserIP()."', $amount, $status, '".$this->GetTime()."')";
			$this->LogError("Error : " .$update);
			$this->LogError("Card : " . $card);
			$this->LogError("User : " . $user);
			$this->LogError("IP : " . $this->GetUserIP());
			$this->LogError("Amount : " . $amount);
			$this->LogError("Status : " . $status);
			$this->LogError("Time : " . $this->GetTime());
			$this->LogError("=============================================================");
			
		}
		if($amount > 0 && !$this->Update($this->tbName, $this->fdCS, $this->GetPoint($amount), $user)){
			//หาก update ไม่ได้ให้สร้าง error log
			$update = "UPDATE member SET Point = Point + $this->GetPoint($amount) WHERE Username = '".$_SESSION["UID"]."' ";;
			$this->LogError("Error : " . $update);
			$this->LogError("User : " . $user);
			$this->LogError("Amount : " . $this->GetPoint($amount));
			$this->LogError("Time : " . $this->GetTime());
			$this->LogError("=============================================================");
		}
		return $status;
		echo "</div>";
	}
	
	/**/
	public function Connect(){
		$this->DbQuery = new mysqli($this->DbHost, $this->DbUser, $this->DbPass, $this->DbName, $this->DbPort);
		if ($this->DbQuery->connect_errno) 
		{
			printf("Connect failed: %s
", $this->DbQuery->connect_error);
			exit();
		}
		$this->DbQuery->query("SET NAMES UTF8");
	}
	
	/**/
	public function Close(){
		$this->DbQuery->close();
	}
	
	/*
	@param1 $user = ไอดี 
	@param2 $card = หมายเลขบัตรทรูมันนี่
	@param3 $amount = ราคาบัตร
	@param4 $status = สถานะ
	*/
	private function InsertCard($user, $card, $amount, $status){
		$query = "INSERT INTO truemoney (card, uid, uip, amount, status, time) VALUES ('$card', '$user', '".$this->GetUserIP()."', $amount, $status, '".$this->GetTime()."')";
		if(!mysqli_query($this->DbQuery, $query))
		{
			return false;
		}
		return true;
	}
	
	/*
	@param1 $table = ชื่อตารางของฐานข้อมูล
	@param2 $column = ชื่อคอลั่มน์ของฐานข้อมูล 
	@param3 $value = ค่าที่จะอัพเดท ตัวอย่าง หากต้องการลบให้ใส่ -5 / หากต้องการบวกให้ใส่ 5
	@param4 $where = จะให้อัพเดทที่ไอดีไหน/ตรงไหน
	*/
	private function Update($tbName, $fdCS, $amount, $where){
		$query = ("UPDATE member SET Point = Point + $this->GetPoint($amount) WHERE Username = '".$_SESSION["UID"]."' ");
		if(!mysqli_query($this->DbQuery, $query))
		{
			
			return false;
		}
		return true;
	}
	
	/*
	@param1 $user = ไอดี
	@param2 $pass = พาส
	@param3 $md5  = 0 ไม่ใช้ md5 / 1 ใช้ md5
	ตัวอย่าง ไม่ใช้ MD5 = LogIn('testID', 'testPS', 0);
	ตัวอย่าง ใช้ MD5 = LogIn('testID', 'testPS', 1);
	*/
	public function Login($user, $pass, $md5){
		$pass = $md5 > 0 ? md5($pass) : $pass;
		$query = "SELECT * FROM $this->tbName where $this->fdID = '$user' and $this->fdPS = '$pass'";
		if(!mysqli_query($this->DbQuery, $query))
			return false;
		
		$result = $this->DbQuery->query($query);
		if ($result->num_rows <= 0)
			return false;

		return true;
	}
	
	/*
	@param1 $card = เลขบัตรทรูมันนี่
	*/
	private function CheckCard($card){
		$result = $this->DbQuery->query("SELECT card FROM truemoney WHERE card = '$card'");
		if ($result->num_rows > 0)
			return false;
		return true;
	}
			
	private function GetPoint($amount){
		if($amount == 50)
			return $this->point1;
		else if($amount == 90)
			return $this->point2;
		else if($amount == 150)
			return $this->point3;
		else if($amount == 300)
			return $this->point4;
		else if($amount == 500)
			return $this->point5;
		else if($amount == 1000)
			return $this->point6;
		return 0;
	}

	private function GetUserIP()
	{
		$client  = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote  = @$_SERVER['REMOTE_ADDR'];
		if(filter_var($client, FILTER_VALIDATE_IP))
			$ip = $client;
		elseif(filter_var($forward, FILTER_VALIDATE_IP))
			$ip = $forward;
		else
			$ip = $remote;
		return $ip;
	}
	
	private function GetTime()
	{
		return date("Y-m-d H:i:s");
	}
	
	/*
	@param1 $str = log text
	*/
	private function LogError($str){
		if (!file_exists('log')) {
			@mkdir('log', 0777, true);
			@file_put_contents('log/index.html', '');
		}
		$now1 = date("Y-m-d");
		$now2 = date("Y-m-d H:i:s");	
		$file = 'log/log_'.$now1.'.txt';
		$current = @file_get_contents($file);
		$current .= '['.$now2.'] '.$str."
";
		@file_put_contents($file, $current);
	}
}
?>
<?php
@session_start();
if(!isset($_SESSION['UID']))
	$_SESSION['UID'] = '';
		
?>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> 
</head> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php
if($_SESSION['UID'] == '')
{
	echo "";
echo $TM_2DTHLog;
echo "
";
}
else
{
echo "";
echo $TM_2DTHPay;
echo "
";
}
?></title>
	<script type="text/javascript">
	function isNumberKey(evt){
		var charCode = (evt.which) ? evt.which : event.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	}
	</script>
  </head>
  <body>
<?php
if($_SESSION['UID'] == '')
{
?>
<html>
<head>
<meta charset='UTF-8'>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<title><?php require("../setting.php"); echo $TM_2DTHLog;
?> </title>
</head>
<div class="list-group">
  <a href="#" class="list-group-item active">
    <h4 class="list-group-item-heading"><?php require("../setting.php"); echo $TM_2DTHTm;
?> </h4>
    <p class="list-group-item-text"><?php require("../setting.php"); echo $TM_2DTHRlog;
?> </p>

  </a>
    <div align="right" class="list-group-item">
<marquee><?php require("../setting.php"); echo $TM_2DTHPos;
?> </marquee>

	</div>
</div>
<div align="center">
 <?
	if($_GET['reg'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-success'>";
echo $TM_2DTHRegs;
echo "
</span>";
	}
	?>
	</div>
<div class="row">
    <div class="Absolute-Center is-Responsive">
      <div id="logo-container"></div>
      <div class="col-sm-12 col-md-10 col-md-offset-1">
<form name="form1" method="post">
	  <?
	if($_GET['error'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $TM_2DTHErr;
echo "
</span>";
	}
	?><br>
 <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input class="form-control" type="text" name='user' placeholder="<?php require("../setting.php"); echo $TM_2DTHUs;
?> "/>          
          </div>
	
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
            <input class="form-control" type="password" name='pass' placeholder="<?php require("../setting.php"); echo $TM_2DTHPs;
?> "/>     
          </div>
          <div class="checkbox">
            <label>
              <input type="checkbox"> <?php require("../setting.php"); echo $TM_2DTHCh;
?>  
            </label>
          </div>
          <div class="form-group">
            <input name="login" class="btn btn-def btn-block" type="submit" name="Submit" value="<?php require("../setting.php"); echo $TM_2DTHLogi;
?> ">
          </div>
          <div class="form-group text-center">
            <a href="../register.php"><?php require("../setting.php"); echo $TM_2DTHRegi;
?> </a>&nbsp;|&nbsp;<a href="../about.php"><?php require("../setting.php"); echo $TM_2DTHTerm;
?> </a>
          </div>
</form>
</div>
</div>
</div>


<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</body>
</html>
							<?php
								if(!isset($_POST['login']))
									$_POST['login'] = '';
								else
								{
									include("cs.2dth.club.truewallet.php");
									
									$wallet = new TrueWallet();
									$wallet->Connect();
									if(!$wallet->Login($_POST['user'],$_POST['pass'],false))
										header("Location: tmpay.php?error=suc");
									else
									{
										$_SESSION['UID'] = $_POST['user'];
										header("Location: tmpay.php");
									}
								}
							}
							else if($_SESSION['UID'] <> '')
							{
							?>
<html>
<head>
<meta charset='UTF-8'>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<title><?php require("../setting.php"); echo $TM_2DTHTmp;
?></title>
</head>
							<form name="form1" method="post">
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("../setting.php"); echo $TM_2DTHPoius;
?>  <?echo $_SESSION['UID'];  ?>
	<?
	if($_GET['set'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-success'>";
echo $TM_2DTHSuc;
echo "
</span>";
	}
	?></h3>
  </div>
  <div class="panel-body">
<div class="row">
<div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?php require("../setting.php"); echo $TM_2DTHNum;
?></button>
      </span>
      <input type="text" id="number" name="number" class="form-control" placeholder="<?php require("../setting.php"); echo $TM_2DTHNumb;
?>" onkeypress="return isNumberKey(event)" maxlength=14 required autocomplete="off">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->

  <div class="col-lg-6">
  <?
	if($_GET['cap'] == '')
	{
		
	}
	else
	{
	echo "<span class='label label-danger'>";
echo $TM_2DTHRcap;
echo "
</span>";
	}
	?>
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button"><?
function generateRandomString($length = 5) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
echo generateRandomString();
?></button>
      </span>
      <input name="2dthCap" type="text" maxlength=5 required autocomplete="off" class="form-control" placeholder="<?php require("../setting.php"); echo $TM_2DTHCap;
?>...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->


</div><!-- /.row --><br><br>
<?php

								if(!isset($_POST['topup']))
								$_POST['topup'] = '';
						       else
								{
							
									include("cs.2dth.club.truewallet.php");
									$wallet = new TrueWallet();
									$wallet->Connect();
									$a = $wallet->Topup($_SESSION['UID'],$_POST['number']);
									
									print_r($a);
									
								}
								if(!isset($_POST['logout']))
									$_POST['logout'] = '';
								else
								{
									@session_destroy();
									header("Location: ./");
								}
								
							?>
 </div>
</div>
<br><br>

<div align="center">
      <input type="submit" name="topup" value="<?php require("../setting.php"); echo $TM_2DTHConf;
?>" class="btn btn-default">
      <a onclick="goBack()" value="<?php require("../setting.php"); echo $TM_2DTHCance;
?>" class="btn btn-default"><?php require("../setting.php"); echo $TM_2DTHCance;
?></a>
</form>
							
						<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script>
function goBack() {
    window.location="cache.php?url=../";
}
function goHome() {
    window.location="../";
}
</script>
</body>
</html>

<?
}
							
							?>
<?
header("Location: ../beta.php");
?>
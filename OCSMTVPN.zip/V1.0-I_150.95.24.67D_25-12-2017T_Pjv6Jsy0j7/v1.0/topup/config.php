<?php
//ข้อมูล
//http://tmwallet.thaighost.net ต้องสมัครสมาชิกที่เว็บนี้ก่อนแล้วเอา id มาใส
$tmapi_user="2dth"; // ชื่อผู้ใช้username
$tmpapi_assword="1234"; // รหัสผ่านpassword
$truewall_email="2dth@gmail.com"; // อีเมล์ทรูวอลเลต
$truewall_phone="0999999999"; // เบอร์โทรศัพท์ทรูวอลเล็ต
$truepassword="tmpwoki3sIRVu2VFkUme[pl]SBrYvYwOGwauQAgfZwVTZ4ZNKDh4[tr]"; // รหัสผ่าน ต้องนำรหัสผ่าน True money Wallet ของท่านไปเข้ารหัสความปลอดภัยที่ http://tmwallet.thaighost.net/tmclient.php ก่อนแล้วนำcodeที่ได้หลังเข้ารหัสมาใส่ตรงนี้ได้เลย  รูปแบบ tmpw..................
//จบข้อมูล//
require("../setting.php");
$objConnect = mysql_connect("$S_2DTHdbhost","$S_2DTHdbuser","$S_2DTHdbpass") or die("Error Connect to Database");
$objDB = mysql_select_db("$S_2DTHdbname");
mysql_query("SET character_set_results=utf8");
mysql_query("SET character_set_client=utf8");
mysql_query("SET character_set_connection=utf8");
?>
<?
include("header.php");
?>
<title><?php require("setting.php"); echo $HW_2DTH; echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<body>
<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $S_2DTHName; echo "&nbsp;"; echo $S_2DTHBuy;?></h3>
  </div>
  <div class="panel-body">
    <marquee><?php require("setting.php"); echo $HW_2DTHPos;?></marquee>
  </div>
</div>
<div class="jumbotron">
  <h1><?php
    require("setting.php");
    $words = array($HW_2DTHW1,$HW_2DTHW2,$HW_2DTHW3,$HW_2DTHW4,$HW_2DTHW5);
    echo $words[rand(0, count($words)-1)];
?></h1>
  <p>
  <font color="red"><?require("setting.php"); echo $HW_2DTHQ1;?></font><br>
<?require("setting.php"); echo $HW_2DTHR1;?>
  </p>
  <p>
  <font color="red"><?require("setting.php"); echo $HW_2DTHQ2;?></font><br>
<?require("setting.php"); echo $HW_2DTHR2;?>
  </p>
  <p>
  <font color="red"><?require("setting.php"); echo $HW_2DTHQ3;?></font><br>
<?require("setting.php"); echo $HW_2DTHR3;?>
  </p>
  <p><a class="btn btn-primary btn-lg" href="login.php" role="button"><?require("setting.php"); echo $HW_2DTHLog;?></a><a class="btn btn-primary btn-lg" href="register.php" role="button"><?require("setting.php"); echo $HW_2DTHReg;?></a></p>
</div>

<div class="row">




  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">

     <img src="<?require("setting.php"); echo $HW_2DTHVpic;?>" alt="https://2dth.club">
      <div class="caption">
       <h3><?require("setting.php"); echo $HW_2DTHVPN;?></h3>
        <p><?require("setting.php"); echo $HW_2DTHVdet;?></p>
        <p><a href="<?require("setting.php"); echo $HW_2DTHVl1;?>" class="btn btn-primary" role="button"><?require("setting.php"); echo $HW_2DTHV1;?></a> <a href="<?require("setting.php"); echo $HW_2DTHVl2;?>" class="btn btn-default" role="button"><?require("setting.php"); echo $HW_2DTHV2;?></a></p>
      </div>
    </div>
  </div>

   <div class="col-sm-6 col-md-4">
    <div class="thumbnail">

     <img src="<?require("setting.php"); echo $HW_2DTHOpic;?>" alt="https://2dth.club">
      <div class="caption">
       <h3><?require("setting.php"); echo $HW_2DTHOpen;?></h3>
        <p><?require("setting.php"); echo $HW_2DTHOdet;?></p>
        <p><a href="<?require("setting.php"); echo $HW_2DTHOl1;?>" class="btn btn-primary" role="button"><?require("setting.php"); echo $HW_2DTHO1;?></a> <a href="<?require("setting.php"); echo $HW_2DTHOl2;?>" class="btn btn-default" role="button"><?require("setting.php"); echo $HW_2DTHO2;?></a></p>
      </div>
    </div>
  </div>

   <div class="col-sm-6 col-md-4">
    <div class="thumbnail">

     <img src="<?require("setting.php"); echo $HW_2DTHHpic;?>" alt="https://2dth.club">
      <div class="caption">
       <h3><?require("setting.php"); echo $HW_2DTHHttp;?></h3>
        <p><?require("setting.php"); echo $HW_2DTHHdet;?></p>
        <p><a href="<?require("setting.php"); echo $HW_2DTHHl1;?>" class="btn btn-primary" role="button"><?require("setting.php"); echo $HW_2DTHH1;?></a> <a href="<?require("setting.php"); echo $HW_2DTHHl2;?>" class="btn btn-default" role="button"><?require("setting.php"); echo $HW_2DTHH2;?></a></p>
      </div>

    </div>
  </div>



</div>

<?
include("footer.php");
?>
</body>
</html>
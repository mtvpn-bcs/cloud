<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<title><?php require("setting.php"); echo $WS_2DTHWar;?></title>
</head>
<div class="list-group">
  <a href="#" class="list-group-item active">
    <h4 class="list-group-item-heading"><?php require("setting.php"); echo $WS_2DTHWarn;?></h4>
    <p class="list-group-item-text"><?php require("setting.php"); echo $WS_2DTHRea;?></p>

  </a>
    <div align="right" class="list-group-item">
<?php
require "../setting.php" ;
$filename = '2dth.web.ssh.vpn.sql';


mysql_connect($S_2DTHdbhost, $S_2DTHdbuser, $S_2DTHdbpass) or die('Error connecting to MySQL server: ' . mysql_error());
mysql_select_db($S_2DTHdbname) or die('Error selecting MySQL database: ' . mysql_error());

$templine = '';
$lines = file($filename);
foreach ($lines as $line)
{
if (substr($line, 0, 2) == '--' || $line == '')
    continue;

$templine .= $line;
if (substr(trim($line), -1, 1) == ';')
{
    mysql_query($templine) or print('Error performing query \'<strong>' . $templine . '\': ' . mysql_error() . '<br /><br />');
    $templine = '';
}
header("location:step-4.php?installs=oks&setting=now&index=yes&install=ok");
}
?>
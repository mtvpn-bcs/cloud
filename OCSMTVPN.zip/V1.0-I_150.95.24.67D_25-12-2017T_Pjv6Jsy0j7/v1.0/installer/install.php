﻿<html>
<head>
<meta charset='UTF-8'>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="../css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="../js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<title>ติดตั้ง 2DTHVPNSSH WEBRESELLER</title>
</head>
<div class="list-group">
  <a href="#" class="list-group-item active">
    <h4 class="list-group-item-heading">ติดตั้ง 2DTHSSHVPN @AINZ&SKYTSDEV</h4>
    <p class="list-group-item-text">สคริปนี้ทำการจัดจำหน่ายโดย SkyTsDev เท่านั้นโดยผลงานชิ้นนี้จะมีจำหน่ายเพียงสองที่คือ shop.2dth.club เเละทางใลน์ 2DTH Official เท่านั้น เนื่องจากนี่เป็นทรัพท์สินทางปัญญาหากพบว่ามีการนำไปเเจกฟรี ทำซ้ำหรือดัดเเปลง โดยไม่ได้รับอนุญาต เราจะดำเนินคดีไม่ว่าท่านจะมีข้ออ้างใดๆ</p>

  </a>
    <div align="right" class="list-group-item">
<marquee>ขอขอบคุณที่ไว้วางใจเเละสั่งซื้อ</marquee>

	</div>
</div>
<div align="center">
	</div>
<div align="center" class="row">
    <div align="center" class="Absolute-Center is-Responsive">
      <div align="center" id="logo-container"></div>
      <div align="center" class="col-sm-12 col-md-10 col-md-offset-1">
<form name="form1" method="post" action="step-2.php">
	<br>

	<div class="form-group input-group">
<div class="alert alert-danger" role="alert">กรุณาตรวจเช็คก่อนติดตั้งให้ครบถ้วนเพื่อกันความผิดพลาด</div>   
          </div>

		  <div class="form-group input-group">
<div class="alert alert-info" role="alert"><b>ความต้องการระบบ PHP 5.0+</b> เวอร์ชั่นปัจจุบัน : <?$version = phpversion();
print $version;?></div>   
          </div>


 <div class="form-group input-group">
<?require "../setting.php" ;
$div1 = "<div class='alert alert-danger' role='alert'>";
$div_01 = "<b>MySql </b>ขออภัยระบบไม่สามารถเชื่อมต่อไปยัง MySql ได้ ";
$div_1 = "</div>";
$div2 = "<div class='alert alert-success' role='alert'>";
$div_02 = "<b>MySql </b>ยินดีด้วยระบบสามารถเชื่อมต่อ MySql ได้ ";
$div_2 = "</div>";
mysql_connect($S_2DTHdbhost, $S_2DTHdbuser, $S_2DTHdbpass) or die ("$div1 $div_01 $div_1");
mysql_select_db($S_2DTHdbname) or die ("$div1 $div_01 $div_1");
echo "$div2 $div_02 $div_2";?>
          </div>
	
          <div class="form-group input-group">
<div class="alert alert-warning" role="alert">พื้นที่ว่างขั้นต่ำ <b>50Mb</b> คงเหลือ<?$df = round(disk_free_space("var/www/") / 1024 / 1024 / 1024);
print(" : $df GB");?></div>   
          </div>

		  <div class="form-group input-group">
<div class="alert alert-danger" role="alert">เพื่อความสดวกกรุณาเช็คว่าเป็น <b>777</b> Permissions : <? echo substr(decoct(fileperms('../')), -3);?></div>   
          </div>


          <div class="checkbox">
            <label>
			
              <input type="checkbox">
			  ยืนยันการติดตั้ง
            </label>
          </div>
		  <br><br><br><br>
          <div class="form-group">
            <input class="btn btn-def btn-block" type="submit" name="Submit" value="ต่อไป">
          </div>
          <div class="form-group text-center">
            <a href="https://2dth.club">2DTH</a>&nbsp;|&nbsp;<a href="https://skytsdev.2dth.club">SkyTsDev</a>
          </div>
</form>
</div>
</div>
</div>
</body>
</html>
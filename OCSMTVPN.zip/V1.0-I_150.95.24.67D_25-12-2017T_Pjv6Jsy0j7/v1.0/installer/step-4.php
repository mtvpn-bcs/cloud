<html>
<head>
<meta charset='UTF-8'>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="../css/bootstrap.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src="../js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<title>ขอขอบคุณที่ติดตั้ง 2DTHVPNSSH WEBRESELLER</title>
</head>
<div class="list-group">
  <a href="#" class="list-group-item active">
    <h4 class="list-group-item-heading">ติดตั้ง 2DTHSSHVPN @AINZ&SKYTSDEV</h4>
    <p class="list-group-item-text">สคริปนี้ทำการจัดจำหน่ายโดย SkyTsDev เท่านั้นโดยผลงานชิ้นนี้จะมีจำหน่ายเพียงสองที่คือ shop.2dth.club เเละทางใลน์ 2DTH Official เท่านั้น เนื่องจากนี่เป็นทรัพท์สินทางปัญญาหากพบว่ามีการนำไปเเจกฟรี ทำซ้ำหรือดัดเเปลง โดยไม่ได้รับอนุญาต เราจะดำเนินคดีไม่ว่าท่านจะมีข้ออ้างใดๆ</p>

  </a>
    <div align="right" class="list-group-item">
<marquee>ขอขอบคุณที่ไว้วางใจเเละสั่งซื้อ</marquee>

	</div>
</div>
<div align="center">
	</div>
<div align="center" class="row">
    <div align="center" class="Absolute-Center is-Responsive">
      <div align="center" id="logo-container"></div>
      <div align="center" class="col-sm-12 col-md-10 col-md-offset-1">
<form name="form1" method="post" action="../">
	<br>

	<div class="form-group input-group">
<div class="alert alert-danger" role="alert">กรุณาตรวจเช็คว่าระบบได้ลบโฟลเดอร์ insaller ไปหรือยังเพื่อความปลอดภัย</div>   
          </div>

		  <div class="form-group input-group">
<div class="alert alert-info" role="alert"><?php
if($_GET["setting"] == "now")
 {
$Site = $_SERVER['SERVER_NAME'];
$to      = 'm.skycore@gmail.com';
$subject = 'New! Install 2DTH WEBVPN';
$message = 'ตัวสคริปได้ทำการติดตั้งลงที่เว็บ $Site เเล้ว';
$headers = 'From: service@2dth.club' . "\r\n" .
    'Reply-To: support@2dth.club' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
  }
?><b>ส่งข้อความตรวจสอบไปยังผู้ดูเเลเว็บเเล้ว</b>ขอขอบคุณที่เลือกใช้งาน</div>   
          </div>


 <div class="form-group input-group">
<div class='alert alert-success' role='alert'>
<?php
if($_GET["install"] == "ok")
 {
	unlink('2dth.web.ssh.vpn.sql');
	unlink('index.php');
	unlink('install.php');
	unlink('review.php');
	unlink('step-2.php');
	unlink('step-3.php');
	unlink('step-4.php');
	rmdir('../installer/');
 }
?>
<?php
if($_GET["installs"] == "oks")
 {
	unlink('2dth.web.ssh.vpn.sql');
	unlink('index.php');
	unlink('install.php');
	unlink('review.php');
	unlink('step-2.php');
	unlink('step-3.php');
	unlink('step-4.php');
	rmdir('../installer/');
 }
?><b>สำเร็จ  </b>ยินดีด้วยระบบสามารถลบโฟลเดอร์ได้ 
</div>
 </div>
	
 <div class="form-group input-group">
<div class='alert alert-success' role='alert'>
<?php
if($_GET["index"] == "yes")
 {
    unlink('../index.php');
    rename('../2dth.php', '../index.php');
 }
?><b>สำเร็จ  </b>ยินดีด้วยระบบสามารถใช้งานเว็บไซต๋ได้เเล้ว
</div>
 </div>


          <div class="checkbox">
            <label>
			
              <input type="checkbox">
			  ยืนยันการใช้งาน
            </label>
          </div>
		  <br><br><br><br>
          <div class="form-group">
            <input class="btn btn-def btn-block" type="submit" name="Submit" value="คลิ๊กที่นี่เพื่อปิดหน้านี้">
          </div>
          <div class="form-group text-center">
            <a href="https://2dth.club">2DTH</a>&nbsp;|&nbsp;<a href="https://skytsdev.2dth.club">SkyTsDev</a>
          </div>
</form>
</div>
</div>
</div>
</body>
</html>
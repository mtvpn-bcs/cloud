<?
include("header.php");
?>
<title><?php require("setting.php"); echo $S_2DTHName; echo "&nbsp;"; echo $S_2DTHBuy;?></title>
<body>
<script>
function copyToClipboard(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}
</script>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

	if($_SESSION['Status'] != "USER")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNsta;
	    echo "&nbsp;คำอธิบาย&nbsp;";
		echo $S_2DTHRuser;
		echo $S_2DTHAdmin;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSlog;
        echo "</a>";
        echo " <a href='logout.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSout;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}		

include("include/db.config.inc.php");
include("nav.php");
$strSQL = "SELECT * FROM SIB";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");
$Num_Rows = mysql_num_rows($objQuery);

$strSQL .=" order by SIB DESC";
$objQuery  = mysql_query($strSQL);
?>
<div class="row">
<div class="list-group">
<?
while($objResult = mysql_fetch_array($objQuery))
{
?>

 <div class="col-sm-6 col-md-4 col-lg-3">
  <a href="#" class="list-group-item disabled">
    <?=$objResult['SIN'];?>
  </a>

  <a onclick="copyToClipboard('#<?=$objResult['SIN'];?>')" href="https://check-host.net/ip-info?host=<?=$objResult['SIA'];?>" class="list-group-item"><i class="glyphicon glyphicon-hdd" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHHip;
?><span class="badge"><text id="<?=$objResult['SIN'];?>"><?=$objResult['SIA'];?></text></span> </a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-credit-card" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHPc;
?> <span class="badge"><?=$objResult['SIB'];?></span></a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-globe" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHZone;
?> <span class="badge"><?=$objResult['SIT'];?>  <img width="10" height="10" src="img/region/2dth.club-<?=$objResult['SIT'];?>.png" alt="<?=$objResult['SIN'];?>"></span></a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-resize-small" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHOsshp;
?> <span class="badge"><?php require("setting.php"); echo $S_2DTHPossh;
?></span></a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-resize-small" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHDbearp;
?> <span class="badge"><?php require("setting.php"); echo $S_2DTHPdbear;
?></span></a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-resize-small" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHOpvpnp;
?> <span class="badge"><?php require("setting.php"); echo $S_2DTHPovpn;
?></span></a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-resize-small" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHBvpnp;
?> <span class="badge"><?php require("setting.php"); echo $S_2DTHPbad;
?></span></a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-tint" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHSproxp;
?> <span class="badge"><?php require("setting.php"); echo $S_2DTHPprox;
?></span></a>

  <a onclick="copyToClipboard('#<?=$objResult['SIN'];?>')" href="#" class="list-group-item"><i class="glyphicon glyphicon-cloud" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHSprox;
?> <span class="badge"><text id="<?=$objResult['SIN'];?>"><?=$objResult['SIA'];?></text></span></a>

  <a href="check.php?server=<?=$objResult['SID'];?>&servers=check" class="list-group-item"><i class="glyphicon glyphicon-signal" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHServoo;
?> <span class="badge"><?php
$host = $objResult['SIA'];
if($socket =@ fsockopen($host, 80, $errno, $errstr, 30)) {
echo $S_2DTHIpon;
fclose($socket);
} else {
echo $S_2DTHIpof;
}
?></span></a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHConnv;
?> <span class="badge"><?php require("setting.php"); echo $S_2DTHConne;
?></span></a>

  <a href="#" class="list-group-item"><i class="glyphicon glyphicon-calendar" aria-hidden="true"></i> <?php require("setting.php"); echo $S_2DTHExd;
?> <span class="badge"><?php require("setting.php"); echo $S_2DTHDay;
?></span></a>


  <div align="center" class="list-group-item">
  
  <a href="server-user.php?s=<?=$objResult['SID'];?>" class="btn btn-default btn-lg"><?php require("setting.php"); echo $S_2DTHBbsv;
?></a>
  <div class="btn-group" role="group" aria-label="...">
  <a href="conf/dl.php?s=<?=$objResult['SID'];?>.ovpn" class="btn btn-warning"><?php require("setting.php"); echo $S_2DTHOpvpncf;
?></a>
  <a href="conf/dl.php?s=<?=$objResult['SID'];?>.ehi" class="btn btn-primary"><?php require("setting.php"); echo $S_2DTHHincf;
?></a>
</div>
</div>
<br>
 </div>

    <?
}
?>
</div>
</div>

<?
include("footer.php");
?>
</body>
</html>
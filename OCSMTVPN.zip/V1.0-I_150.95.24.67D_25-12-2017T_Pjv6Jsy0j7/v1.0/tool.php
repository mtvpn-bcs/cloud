<?
include("header.php");
?>
<title><?php require("setting.php"); echo $NU_2DTHNouse; echo "&nbsp;-&nbsp;"; echo $S_2DTHName;?></title>
<?
	session_start();
	if($_SESSION['UserID'] == "")
	{
		require("setting.php");
		include "r-h.php";
		echo "<h4 class='list-group-item-heading'>";
		echo $S_2DTHNlog;
		echo "</h4>";
		echo "<p class='list-group-item-text'>";
		echo " <a href='login.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHLogin;
        echo "</a>";
        echo " <a href='register.php' type='button' class='btn btn-primary' aria-haspopup='true' aria-expanded='false'>
  ";
        echo $S_2DTHSing;
        echo "</a>";
		echo "</p>";
		include "r-f.php";
		exit();
	}

include("nav.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>


<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php require("setting.php"); echo $NU_2DTHNous;?>  
	</h3>
  </div>
  <div class="panel-body">
    <div class="alert alert-danger" role="alert"><?php require("setting.php"); echo $NU_2DTHTx;?> <b><?php require("setting.php"); echo $NU_2DTHCo;?></b>
	<?php require("setting.php"); echo $NU_2DTHSr;?></div>

 </div>
</div>
<br><br>


<?
include("footer.php");
?>
<script>
function goBack() {
    window.location="<?php require('setting.php'); echo $S_2DTHUrl;
?>";
}
</script>
</body>
</html>